package com.pbl.demo.model.has_ingredients; //FIX JpaRepository

import org.springframework.data.jpa.repository.JpaRepository;

public interface HasIngredientsRepository extends JpaRepository<HasIngredients, HasIngredients>{

}
